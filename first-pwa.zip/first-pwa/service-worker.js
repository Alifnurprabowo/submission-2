const CACHE_NAME = 'first-pwa 4';
var urlsToCache = [
  "/",
  "/nav.html",
  "/index.html",
  "/pages/Home.html",
  "/pages/Collection.html",
  "/pages/Call us.html",
  "/pages/Profile.html",
  "/css/materialize.min.css",
  "/js/materialize.min.js",
  "/manifest.json",
  "/js/nav.js",
  "/js/register.js",
  "/js/api.js",
  "/js/database.js",
  "/js/idb.js",
  "/js/indexeddb.js",
  "/js/matches.js",
  "/js/standings.js",
  "/js/teams.js",
  "/js/teamFav.js",
  "/js/playerFav.js",
  "/js/matchFav.js",
  "/detailtim.html",
  "/detailmatch.html",
  "/detailplayer.html",
  "/pict/13.png",
  "/pict/3.jpg",
  "/pict/4.jpg",
  "/pict/6.jpg",
  "https://fonts.googleapis.com/icon?family=Material+Icons",
  "/pict/7.jpg",
  "/pict/16.png"
];
 
const base_url = "https://api.football-data.org/v2";
const base_url2 = "https://upload.wikimedia.org/wikipedia";

// * install
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(urlToCache)
        })
    )
})

// * fetch
self.addEventListener('fetch', event => {
    if (event.request.url.indexOf(base_url) > -1 || event.request.url.indexOf(base_url2) > -1) {
        event.respondWith(
            (async () => {
                const cache = await caches.open(CACHE_NAME)
                const res = await fetch(event.request)
                cache.put(event.request.url, res.clone())
                return res
            })()
        )
    } else {
        event.respondWith(
            (async () => {
                return await caches.match(event.request.url, {
                    ignoreSearch: true
                }) || await fetch(event.request)
            })()
        )
    }
})

// *delete
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then( cacheNames => {
            return Promise.all(
                cacheNames.map( cacheName => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('cache '+cacheName+' dihapus')
                        return caches.delete(cacheName)
                    }
                })
            )
        })
    )
})

// * push notification
self.addEventListener('push', event => {
    console.log(event);
    let body;
    if (event.data) {
        body = event.data.text()
    }else{
        body = "push message no payload"
    }

    let opt ={
        body,
        icon : './pcit/16.png',
        vibrate : [100,50,100],
        data : {
            dateOfArrival : Date.now(),
            primaryKey : 1
        }
    }

    event.waitUntil(
        self.registration.showNotification('Push notification',opt)
    )
})